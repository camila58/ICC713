<template>
  <div>
    <div class="navbar navbar-expand-lg navbar-light bg-light">
      <div class="container-fluid">
        <a class="navbar-brand" href="#">
          <img
            src=""
            alt=""
            width="30"
            height="24"
            class="d-inline-block align-top"
          >
          vuetify
        </a>
      </div>
      <div class="collapse navbar-collapse" id="navbarNav">
        <ul class="navbar-nav">
          <li class="nav-item">
            <a class="nav-link" href="#">Features</a>
          </li>
          <li class="nav-item">
            <a class="nav-link" href="#">Pricing</a>
          </li>
        </ul>
      </div>
    </div>
    <div class="row" v-for="pelicula in peliculas" v-bind:key="pelicula">
      <div class="col-4" >
        <img class="img-fluid" src="https://mdbootstrap.com/img/Photos/Others/images/43.jpg" alt="Card image cap">
        <div class="card-body">
          <!--Title-->
          <h4 class="card-title" >{{pelicula.original_language}}hola</h4>
          <!--Text-->
          <p class="card-text">Some quick example text to build on the card title and make up the bulk of the card's content.</p>
          <a href="#" class="btn btn-primary">Button</a>
        </div>
     </div>
    </div>
  </div>
</template>

<script>
import ApiService from "./service/api.sevice";
export default {
  name: "App",
  components: {},
  data: () => ({
    peliculas: ["el rey leon","rapido y furioso"],
    pagina: 1,
  }),
  methods: {
    cambiarPagina: function () {
      this.peliculas = ApiService.getTopRated(this.pagina + 1);
    
    },
  },
  mounted() {
    this.peliculas = ApiService.getPopular(this.pagina);
    console.log(this.peliculas);
  },
};
</script>

<style>
#app {
  font-family: Avenir, Helvetica, Arial, sans-serif;
  -webkit-font-smoothing: antialiased;
  -moz-osx-font-smoothing: grayscale;
  text-align: center;
  color: #2c3e50;
  margin-top: 60px;
}
.navbar {
  text-align: right;


}
</style>
